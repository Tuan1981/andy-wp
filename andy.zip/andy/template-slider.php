<?php
/**
 * Template Name: Homepage Slider
 *
 * Day la noi hien thi Left Sidebar
 
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Andy
 */

get_header(); ?>

    <section class="section">
      <div class="row">
            <div id="primary" class="col-md-12 col-lg-12">
                <main id="main" class="site-main homepage" role="main">


                    <div id="slider">
                        <ul class="bxslider">
                            <?php $args = array(
                                'posts_per_page' => 4,
                                'orderby' => 'date',
                                'order' => 'DESC',
                                'post_type' => 'post'
                            ); ?>
                            <?php $slider = new WP_Query($args); ?>
                            <?php while($slider->have_posts()): $slider->the_post();  ?>
                                <li>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail('featured'); ?>
                                    </a>
                                </li>
                            <?php endwhile; wp_reset_postdata(); ?>
                        </ul>
                    </div> 
                        
                        <div class="container">
                              <!-- Example row of columns -->
                              <div class="row">
                                <div class="col-md-4">
                                  <h2>Heading</h2>
                                  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                                  <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
                                </div>
                                <div class="col-md-4">
                                  <h2>Heading</h2>
                                  <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>
                                  <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
                               </div>
                                <div class="col-md-4">
                                  <h2>Heading</h2>
                                  <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
                                  <p><a class="btn btn-default" href="#" role="button">View details &raquo;</a></p>
                                </div>
                              </div>

                              <hr>

                       </div><!-- #container -->            
                  </main><!-- #primary -->

          </div><!-- #primary -->
       </div><!-- .row -->
   </section><!-- section -->    

<?php
get_footer();
