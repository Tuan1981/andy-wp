<?php
/**
 * Template Name: Homepage
 *
 * Day la noi hien thi Left Sidebar
 
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Andy
 */

get_header(); ?>

        <div class="container">
          <div class="row">
              
              <div class="jumbotron">
                <h1>Navbar example</h1>
                <p>This example is a quick exercise to illustrate how the default, static navbar and fixed to top navbar work. It includes the responsive CSS and HTML, so it also adapts to your viewport and device.</p>
                <p>
                  <a class="btn btn-lg btn-primary" href="../../components/#navbar" role="button">View navbar docs »</a>
                </p>
              </div>

          </div><!-- #primary -->
       </div><!-- #container -->

<?php
get_footer();
