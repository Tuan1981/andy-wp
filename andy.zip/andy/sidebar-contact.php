<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Andy
 */

if ( ! is_active_sidebar( 'sidebar-contact' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area col-md-3 col-lg-3" role="complementary">
    <div class="panel panel-default">
      <div class="panel-heading"></div>
          <div class="panel-body">
            <?php dynamic_sidebar( 'sidebar-contact' ); ?>
          </div>
    </div>
        
</aside><!-- #secondary -->

</div><!-- .row -->
</div><!-- .container -->
