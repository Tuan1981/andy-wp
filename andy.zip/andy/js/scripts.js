jQuery( function($) {
		  $('.bxslider').bxSlider({
            adaptiveHeight: true,  
		  	mode: 'fade',
            infiniteLoop: true,
            speed: 2000,
            pause: 500,  
            auto: true,
            pager: true,
		  });
	});
				