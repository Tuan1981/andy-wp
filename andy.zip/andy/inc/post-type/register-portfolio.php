<?php 

$portfolio = new CPT(array(
    'post_type_name' => 'portfolio',
    'singular' => __('Portfolio', 'andy'),
    'plural' =>  __('Portfolio', 'andy'),
    'slug' => 'portfolio'
),
                    
 array(
    'supports' => array('title', 'editor', 'thumbnail', 'comments'),
    'menu_icon' => 'dashicons-portfolio'
));

$portfolio->register_taxonomy(array(
    'taxonomy_name' => 'portfolio_tags',
    'singular' => __('Portfolio Tag', 'andy'),
    'plural' => __('Portfolio Tags', 'andy'),
    'slug' => 'portlio-tag'
));
